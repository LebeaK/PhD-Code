﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Smart_Contractual_Layer
{
    public class Sp1_Smart_Contract : ISp1_Smart_Contract
    {
        DataClasses1DataContext data = new DataClasses1DataContext();
        public bool metWeeklyGoal(DateTime date, int weeklygoal)
        {
            var goal = (from g in data.Daily_Activities
                        where g.Activity_Date.Equals(date)
                        select g).FirstOrDefault();

            if (goal.Equals(null))
            {
                return false;
            }
            else
            {
                if (goal.Total_Distance >= weeklygoal)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public UserInformation WeeklyGoalInformation(DateTime date)
        {

            var user = (from u in data.Daily_Activities
                        where u.Activity_Date.Equals(date)
                        select u).FirstOrDefault();

            if (user.Equals(null))
            {
                return null;
            }
            else
            {
                var ui = new UserInformation
                {
                    TotalSteps = user.Total_Steps,
                    TotalDistance = user.Total_Steps,
                    Calories = user.Calories,
                };
                return (ui);
            }
        }

        bool ISp1_Smart_Contract.WeeklyGoalInformation(DateTime date)
        {
            throw new NotImplementedException();
        }
    }
}
