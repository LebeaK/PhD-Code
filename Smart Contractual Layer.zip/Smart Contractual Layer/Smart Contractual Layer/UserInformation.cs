﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Smart_Contractual_Layer
{
    public class UserInformation
    {
        public int TotalSteps;
        public int TotalDistance;
        public int Calories;
    }
}