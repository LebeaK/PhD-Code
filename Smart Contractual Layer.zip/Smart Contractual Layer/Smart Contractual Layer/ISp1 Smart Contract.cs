﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace Smart_Contractual_Layer
{
    [ServiceContract]
    public interface ISp1_Smart_Contract
    {
        [OperationContract]
        bool metWeeklyGoal(DateTime date, int weeklygoal);

        [OperationContract]
        bool WeeklyGoalInformation (DateTime date);
    }
}
